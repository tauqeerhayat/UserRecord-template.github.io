

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="loginForm">
        <div class="login-sec">
            <h1>Login Page</h1>
            <form action="loginsubmit" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control" name="email">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password">
                </div>
                <button type="submit" class="button">Submit</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\account\resources\views/login.blade.php ENDPATH**/ ?>